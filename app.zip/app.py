import streamlit as st
import pandas as pd

# title
st.title('Angel\'s Book Recommender System')

# intro
st.write('Personalized recommendations to help you discover amazing reading experience...')

# read the data
predictions = pd.read_csv('pred.csv')
Books = pd.read_csv('Books.csv')
ratings = pd.read_csv('ratings.csv')


# write a function to return a list of recommended books
def get_recommendations(predictions, user_id, book_df, ratings_df, num_recommendations = 10):

  '''
  Parameters
  ---
  predictions: a list of predictions returned from best_svd.test(testset)
  user_id: a user id, a string
  book_df: all unique books with book id, title and link, a dataframe 
  ratings_df: the existing rating records, a dataframe
  num_recommendations: the number of recommended books to return, a positive integer, default = 10

  Output:
  ---
  for new users:
  print statement and table display
  most_popular_books: books with the highest rating sum, a dataframe, number of rows = num_recommendations

  for existing users:
  print statement and table display
  hist_ratings: highest historical ratings of this user, a dataframe, number of rows = num_recommendations
  recommendations: the most recommended books for this user, a dataframe, number of rows = num_recommendations

  Example
  ---
  >>>> get_recommendations(predictions, user_id = '123abc', book_df, ratings_df, num_recommendations = 2)

  You have rated highly for these books:
  +---------+--------+---------+-----------------+
  | book_id | rating |  title  |      link       |
  +---------+--------+---------+-----------------+
  |    1    |    5   | Sample1 | www.sample1.com |
  |    2    |    5   | Sample2 | www.sample2.com |
  +---------+--------+---------+-----------------+

  We think you might like these books:
  +---------+------------------+---------+-----------------+
  | book_id | predicted rating |  title  |      link       |
  +---------+------------------+---------+-----------------+
  |    3    |       5.1        | Sample3 | www.sample3.com |
  |    4    |       4.9        | Sample4 | www.sample4.com |
  +---------+------------------+---------+-----------------+

  Note
  ---
  The `Predicted Rating` column in `recommendations` dataframe is shown for developing purpose
  When interacting with actual users, it should not be shown
  '''   

  # if the user_id doesn't exist in the database, return a list of the most popular books

  # a list of all existing users
  all_users = ratings_df['user_id'].unique()

  if user_id != '':

    if user_id not in all_users:

    # sort the books by sum of ratings
      most_popular_books = ratings_df.groupby('book_id').sum('rating').sort_values('rating', ascending = False).head(num_recommendations)

    # merge the most popular books with the titles and links
      most_popular_books_list = pd.merge(most_popular_books, book_df, left_on = 'book_id', 
                                           right_on = 'book_id', how = 'left').drop('rating', axis = 1)
      most_popular_books_list = most_popular_books_list[['book_id', 'title', 'link']]

    # display and return    
      st.write('You don\'t have rating records in our database.')
      st.write('Here are some very popular books you might like:')
      st.dataframe(most_popular_books_list)

  # ---------------------------------
  # ---------------------------------
    else:
  
  # if the user_id exists in the database, return a list of books rated the highest by this user, and a list of recommended books

  # part 1: get hist_ratings

  # get all rating records for the given user
      hist_user = ratings_df[ratings_df['user_id'] == user_id]

  # total number of historical ratings from this user
      num_rated = hist_user.shape[0]

  # sort the records by ratings and only take the top ones (row number: num_recommendations)
      hist_top = hist_user.sort_values('rating', ascending = False).head(num_recommendations)

  # if this user has rated less books than num_recommendations, only return the books rated
      hist_top = hist_top[hist_top['rating'] != 0]

  # merge hist_top with book_df to get titles and links
      hist_ratings = pd.merge(hist_top[['book_id', 'rating']], book_df[['title', 'link', 'book_id']], 
                             left_on = 'book_id', right_on = 'book_id', how = 'left')

  # ---------------------------------

  # part 2: get recommendations

  # put predictions (returned from best_svd.test(testset)) to a dataframe
      predictions_df = pd.DataFrame(predictions)

  # select the predictions only for the given user
      predictions_user = predictions_df[predictions_df['uid'] == user_id]

  # sort the predictions and select the top n
      top_predictions = predictions_user.sort_values(['est'], ascending = False).head(num_recommendations)

  # merge top_predictions with book_df to get titles and links
      recommendations = pd.merge(top_predictions[['iid', 'est']], book_df[['title', 'link', 'book_id']], 
                             left_on = 'iid', right_on = 'book_id', how = 'left')
  
  # clean up column names
      recommendations.drop('book_id', axis = 1, inplace = True)
      recommendations.rename(columns = {'est': 'predicted rating',
                                    'iid': 'book_id'}, inplace = True)
  
  # round predicted ratings to 1 decimal place
      recommendations['predicted rating'] = recommendations['predicted rating'].apply(lambda x: round(x, 1))
    
  # display two tables
      st.write(f'You have rated {num_rated} books in total.')
      st.write(f'The more books you rate, the better recommendations we can offer!')
      st.write('\n')

      st.write('You have rated highly for these books:')
      st.dataframe(hist_ratings.drop('link', axis = 1))
      st.write('\n')

      st.write('We think you might like these books:')
      st.dataframe(recommendations.drop('predicted rating', axis = 1))

  # return two dataframes for potential further processing
  # return hist_ratings, recommendations

users_rate_the_most = ratings.groupby('user_id').count()['rating'].head()
users_rate_the_most = users_rate_the_most.rename_axis('user_id').reset_index()['user_id']

# sample user ids
st.subheader('Sample user ids')
st.write('These users have rated the most...')
st.dataframe(users_rate_the_most)

# my recs
st.subheader('My recommendations')

# take user id from input
with st.form(key='my_recs'):    
    my_user_id = st.text_input(label='Enter your user id:')
    num_recommendations = st.select_slider(label = 'Number of recommendations:', options = list(range(1, 11)))
    submit_button = st.form_submit_button(label='Get my next reading list!')
    get_recommendations(predictions = predictions, user_id = my_user_id, book_df = Books, ratings_df = ratings, num_recommendations = num_recommendations)


# space
st.write('\n')
st.write('\n')
st.write('\n')
st.write('\n')
st.write('\n')
st.write('\n')

# show an image of books
st.image('./books.png')
